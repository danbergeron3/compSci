/**********************************************************************
 *                                                  
 *  PS2a: Sokoban
 **********************************************************************/

Name:Daniel Bergeron

Hours to complete assignment : 15hrs

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 ********************************************************************/
I need to fix the draw fucntion for my next submission it currently does \
not work as intended.


/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  
 **********************************************************************/
No


/**********************************************************************
 *  Did your code pass cpplint?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/
Yes

/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/
Extra help


/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/
Getting the draw function stub to work was a challenge.

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/
